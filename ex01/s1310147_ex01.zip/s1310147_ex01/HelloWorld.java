class HelloWorld{
 public static void main(String[] args){
 // your codes
 System.out.println("Hello World");
 }
}
